package bianry;

import java.util.Scanner;
class P
{
	
	public void put(Book key, String s1[])
	{
		int val=Integer.parseInt(s1[4]);
		Node n=new Node(key ,val);
			
	}
	public void createnode()
	{
		
	}
}
class Node
{
	Node tree;
	Book key;
	int value;
	public Node(Book key,int val)
	{
	this.key=key;
	this.value=val;
	}
}
class Book
{
	String Name,Author;
	Double price;
	public void book(String n,String Author,Double p)
	{
		Name=n;
		Author=Author;
		price=p;
	}
}
public class solution {
public static void main(String [] args)
{
	System.out.println("saas");
	Scanner sc=new Scanner(System.in);
	P obj=new P();
	Book obj1=new Book();
	while(sc.hasNext())
	{
		String s=sc.nextLine();
		String s1[]=s.split(",");
		if(s1[0]=="put")
		{
		String name=s1[1];
		String author=s1[2];
		double price=Double.parseDouble(s1[3]);
		 
		 obj1.book(name, author, price);
		 obj.createnode();
		}
		else if(s1[0]=="get")
		{
			
		}
	}
}
}
